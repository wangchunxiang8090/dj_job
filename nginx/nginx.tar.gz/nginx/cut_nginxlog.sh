#!/bin/bash
#这个脚本须在每天00:00运行

#Nginx日志文件的存放路径
logs_path="/usr/local/nginx/logs/"


mkdir -p ${logs_path}$(date -d "yesterday" +"%Y")/$(date -d "yesterday" +"%m")/cas/
mv ${logs_path}/cas/cas.access.log ${logs_path}$(date -d "yesterday" +"%Y")/$(date -d "yesterday" +"%m")/cas/cas_$(date -d "yesterday" +"%Y%m%d").log


kill -USR1 `cat /usr/local/nginx/logs/nginx.pid`
